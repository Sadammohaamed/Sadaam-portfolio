import React from 'react';
import DiceApp from './DiceApp';

function App() {
  return (
    <div>
      <DiceApp />
    </div>
  );
}

export default App;
