
import React, { useState } from 'react';
import dice1 from './dice1.png';
import dice2 from './dice2.png';
import dice3 from './dice3.png';
import dice4 from './dice4.png';
import dice5 from './dice5.png';
import dice6 from './dice6.png';

const DiceApp = () => {
  const [dice, setDice] = useState(1);

  const rollDice = () => {
    const newDice = Math.floor(Math.random() * 6) + 1;
    setDice(newDice);
  };

  const diceImages = [dice1, dice2, dice3, dice4, dice5, dice6];

  return (
    <div>
      <h1>Dice Roller</h1>
      <img src={diceImages[dice - 1]} alt={`dice-${dice}`} />
      <button onClick={rollDice}>Roll Dice</button>
    </div>
  );
};

export default DiceApp;
